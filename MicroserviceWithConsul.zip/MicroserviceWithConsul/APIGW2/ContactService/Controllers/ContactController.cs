﻿using ContactService.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactService.Controllers
{
    [Route("api/contact")]
    public class ContactController : Controller
    {
        private IContactService contactService;

        public ContactController(IContactService _contactService)
        {
            contactService = _contactService;
        }

        [Produces("application/json")]
        [HttpGet("findall")]
        public IActionResult FindAll()
        {
            try
            {
                return Ok(contactService.FindAll());
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
