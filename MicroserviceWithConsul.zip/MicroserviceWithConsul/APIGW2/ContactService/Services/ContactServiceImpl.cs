﻿using ContactService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactService.Services
{
    public class ContactServiceImpl : IContactService
    {
        public List<Contact> FindAll()
        {
            return new List<Contact>
            {
                new Contact { Cell = "1234567890", Name = "haha" },
                new Contact { Cell = "1345678908", Name = "haha2" },
                new Contact { Cell = "2578154354", Name = "haha3" },
                new Contact { Cell = "8996976555", Name = "haha4" },
                new Contact { Cell = "4537854312", Name = "haha5" }
            };
        }
    }
}
