﻿using ContactService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactService.Services
{
    public interface IContactService
    {
        List<Contact> FindAll();
    }
}
